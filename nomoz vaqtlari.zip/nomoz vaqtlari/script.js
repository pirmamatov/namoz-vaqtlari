const URL = "https://islomapi.uz/api/present/day?region=`${selectedValue}`"



function getApi () {
    fetch(URL)
    .then(response =>  response.json())
    .then(data => console.log(data))
    .catch(error => console.log(error))

    

}
getApi()

function getSelectValue () {
    var selectedValue = document.querySelector(".form-select").value;
    console.log(selectedValue);
}
getSelectValue()
